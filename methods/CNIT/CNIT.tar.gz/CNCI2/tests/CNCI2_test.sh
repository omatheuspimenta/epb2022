python ../CNCI2.py -f test_animal.fa -o test_animal -m "ve"
python ../CNCI2.py -f test_plant.fa -o test_plant -m "pl"
python ../CNCI2.py -f test_animal.gtf -o test_animal_gtf -m 've' -g -b hg38.2bit
python ../CNCI2.py -f err.fa -o test_err -m "ve"
