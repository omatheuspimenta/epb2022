args<-commandArgs(TRUE)
inFile=args[1]
outFile=args[2]
esca=read.csv(inFile)
colnames(esca)=c('mlcds','np1','np2','np3','np4','np5')
Color=c("red","blue","CornflowerBlue","LightSkyBlue","DeepSkyBlue","RoyalBlue")
png(outFile,width=800,height=600)
plot(esca$mlcds,col="red",type ="l",ylim=c(min(esca),max(esca)),ylab="CNCI Score",xlab="Transcript length in codons",lwd =2)####MLDS
lines(esca$np1,col="blue",type ="l")
lines(esca$np2,col="CornflowerBlue",type ="l")
lines(esca$np3,col="LightSkyBlue",type ="l")
lines(esca$np4,col="DeepSkyBlue",type ="l")
lines(esca$np5,col="RoyalBlue",type ="l")
#legend("topright",c("MLCDS","np1","np2","np3","np4","np5"),col=Color,text.col=Color)
text(which(esca$mlcds==max(esca)), max(esca), paste0('MLCDS'),col = c("purple"))
dev.off()