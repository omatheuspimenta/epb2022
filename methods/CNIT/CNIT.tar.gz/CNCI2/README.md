### About CNCI2

It is a challenge to classify protein-coding or non-coding transcripts, ...

### Current Version

CNCIv2 2018.11

### Installation
- python package: 
```
pip install sklearn
pip install numpy
```